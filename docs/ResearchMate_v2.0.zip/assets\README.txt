ResearchMate assets folder.

Required: icon128.png (128×128) for the extension icon.
Generate it: open icons/generate_icons.html in a browser and click "Download icon128.png", then save the file here.
